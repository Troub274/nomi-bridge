# ChatGPT ↔ Nomi — Edge bridge

## Install once

1. In Edge, open edge://extensions.
2. Turn on Developer mode.
3. Click Load unpacked and select:
   C:\home\stecla\coding\nomi\browser_bridge\extension
4. Open your ChatGPT and Nomi conversations in two Edge tabs. Refresh both once.
5. Open the ChatGPT ↔ Nomi Bridge extension from Edge's Extensions menu.
6. Click Open Play / Stop controls.

## Start chatting

Select the ChatGPT tab and the Nomi tab, choose whose latest reply starts the conversation, and press Play. The first speaker must already have a reply in its chat. If necessary, send it an opening message yourself first.

The bridge alternates text replies indefinitely while Edge is open and the computer is awake. Stop prevents further sends; something already submitted can still receive a reply. Play resumes the pending turn. Reset discards the pending position and starts again from the selected speaker's latest reply, which may repeat that reply.

If a send is uncertain or a selected chat is reloaded, navigated, or closed, check both chats before using Reset. Do not type in the selected chats while the bridge runs. If a website rejects a long reply, the bridge stops rather than silently truncating it.

## Check the live chat controls

Open the extension on either chat tab and expand Set up this chat's page controls. Preview shows the latest AI reply and whether generation is detected. Verify it shows the complete newest AI reply, without your own text or sidebar content. If a site changes its controls, adjust them there.

Reply completion uses the website's visible generation indicator plus a quiet-time delay (8 seconds by default). A quiet period alone is not a guarantee that a reply is finished. The supplied Nomi controls were derived from its public site code, not a verified logged-in session.

This version connects tabs in the same Edge profile. It does not connect separate browsers or profiles. It forwards text only. It needs no Python, WSL, API key, or local server.

## Validation

Nine automated checks pass: continuous alternation, streaming waits, Stop/Resume, uncertain sends, navigation during a send, drafts, session restoration, wrong-tab delivery, and storage-update feedback prevention. All JavaScript files pass syntax checks. Installation and real ChatGPT/Nomi sending in your logged-in Edge tabs still need live testing.

## Files and data

Load the extension folder, not this parent folder or the zip file. Keep that folder in place after installation. The extension holds recent chat snapshots and relay state in Edge session storage and saves custom control selectors in local extension storage. It has no remote relay server.

Version 0.1.4 sends one message per turn. ChatGPT replies longer than 750 characters are cut to 750 for Nomi, with no extra parts sent. Each Nomi reply goes back to ChatGPT next. The receiving tab is selected automatically before Send to avoid inactive-tab delays. Use Activity → Copy troubleshooting status to report a stall; it excludes message text.

ChatGPT replies now require completion controls on the current response and no streaming marker. Multiple assistant text blocks in that response are read together. If completion cannot be detected, the bridge waits rather than forwarding a partial reply. Twenty-one automated checks pass; the actual page still needs live verification.


Version 0.1.6: after a shortened message is confirmed sent to Nomi, the next Nomi reply forwarded to ChatGPT includes a clearly labeled bridge reminder to keep entire replies within 750 characters. The reminder is added once per truncation and is not added to Nomi's chat itself.


Version 0.1.7 checks streaming markers on the response container itself. Activity records source and outgoing character counts; Copy troubleshooting status includes the last delivery's counts. Live short-fragment diagnosis remains open.


Version 0.1.8 makes Play show immediate progress and errors beside the button, handles unavailable selection storage, and times out unresponsive extension requests. Nomi's input/send/reply selectors were checked against the live logged-in page on October 9. The cause of the user's inert Play button has not yet been confirmed.

